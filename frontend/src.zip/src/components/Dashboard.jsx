import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  LogOut, 
  Download, 
  BookOpen, 
  Users, 
  BarChart3, 
  User,
  Building,
  Calendar
} from 'lucide-react';
import { useAuth } from './AuthContext';

const Dashboard = () => {
  const { user, logout, exportUsers } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [exportLoading, setExportLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:3001/api/estatisticas', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setStats(data.data);
      }
    } catch (error) {
      console.error('Erro ao buscar estatísticas:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    setExportLoading(true);
    setMessage('');

    const result = await exportUsers();

    if (result.success) {
      setMessage('Arquivo Excel exportado com sucesso!');
    } else {
      setMessage(`Erro: ${result.message}`);
    }

    setExportLoading(false);
    setTimeout(() => setMessage(''), 5000);
  };

  const getTipoUsuarioBadge = (tipo) => {
    const colors = {
      'R1': 'bg-blue-100 text-blue-800',
      'R2': 'bg-green-100 text-green-800',
      'R3': 'bg-yellow-100 text-yellow-800',
      'R4': 'bg-orange-100 text-orange-800',
      'R5': 'bg-red-100 text-red-800',
      'Ortopedista': 'bg-purple-100 text-purple-800',
    };

    return (
      <Badge className={colors[tipo] || 'bg-gray-100 text-gray-800'}>
        {tipo}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Sistema de Questões de Ortopedia
            </h1>
            <p className="text-gray-600 mt-1">TARO e TEOT - Plataforma de Estudos</p>
          </div>
          <Button onClick={logout} variant="outline" className="flex items-center gap-2">
            <LogOut className="h-4 w-4" />
            Sair
          </Button>
        </div>

        {/* User Info Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Informações do Usuário
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Nome</p>
                  <p className="font-medium">{user?.nome}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Building className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Hospital</p>
                  <p className="font-medium">{user?.hospital}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Tipo</p>
                  <div className="mt-1">
                    {getTipoUsuarioBadge(user?.tipo_usuario)}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : stats ? (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      Total de Questões
                    </p>
                    <p className="text-2xl font-bold">{stats.total}</p>
                  </div>
                  <BookOpen className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      Questões TEOT
                    </p>
                    <p className="text-2xl font-bold">{stats.teot}</p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      Questões TARO
                    </p>
                    <p className="text-2xl font-bold">{stats.taro}</p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      Áreas de Estudo
                    </p>
                    <p className="text-2xl font-bold">{stats.areas}</p>
                  </div>
                  <Users className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
          </div>
        ) : null}

        {/* Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Acesso às Questões</CardTitle>
              <CardDescription>
                Acesse o banco de questões de ortopedia para estudar
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Agora você tem acesso completo ao sistema de questões. 
                O sistema original pode ser acessado através do backend em execução.
              </p>
              <Button className="w-full" disabled>
                <BookOpen className="mr-2 h-4 w-4" />
                Acessar Questões (Em desenvolvimento)
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Exportar Usuários</CardTitle>
              <CardDescription>
                Baixe uma planilha Excel com todos os usuários cadastrados
              </CardDescription>
            </CardHeader>
            <CardContent>
              {message && (
                <Alert className="mb-4">
                  <AlertDescription>{message}</AlertDescription>
                </Alert>
              )}
              <p className="text-sm text-muted-foreground mb-4">
                A planilha contém informações como nome, email, hospital e tipo de usuário.
              </p>
              <Button 
                onClick={handleExport} 
                disabled={exportLoading}
                className="w-full"
              >
                {exportLoading ? (
                  <>
                    <Download className="mr-2 h-4 w-4 animate-spin" />
                    Exportando...
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" />
                    Exportar para Excel
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>Sistema de Questões de Ortopedia - TARO e TEOT</p>
          <p>Desenvolvido para auxiliar no estudo e preparação de residentes e ortopedistas</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

